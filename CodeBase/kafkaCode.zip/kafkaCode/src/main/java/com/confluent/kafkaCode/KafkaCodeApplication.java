package com.confluent.kafkaCode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaCodeApplication.class, args);
	}

}
