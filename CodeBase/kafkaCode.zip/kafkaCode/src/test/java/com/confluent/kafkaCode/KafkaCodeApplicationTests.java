package com.confluent.kafkaCode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaCodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
